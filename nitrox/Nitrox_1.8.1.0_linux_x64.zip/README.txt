# Intro

Thank you for downloading Nitrox. We hope you'll enjoy the Subnautica multiplayer experience.
Please keep in mind that some aspects of gameplay are not fully synchronized and that some bugs may occur.

You must install .NET 9 in order to run Nitrox : https://dotnet.microsoft.com/en-us/download/dotnet/9.0

Common setup problems :
* Don't put Nitrox into your game folder
* Don't use Nitrox with other mods
* Subnautica has corrupted files

# Tutorials

Step-by-step installation instructions can be found at: https://nitrox.rux.gg/wizard

For instructions on joining a server: https://nitrox.rux.gg/wiki/article/join-nitrox-subnautica-server

For instructions on hosting a server: https://nitrox.rux.gg/wiki/article/run-and-host-nitrox-subnautica-server

# Support

If you ever need help, find us on Discord: https://discord.gg/Rf8n88c

To report any bugs, you can find us on Github : https://github.com/SubnauticaNitrox/Nitrox